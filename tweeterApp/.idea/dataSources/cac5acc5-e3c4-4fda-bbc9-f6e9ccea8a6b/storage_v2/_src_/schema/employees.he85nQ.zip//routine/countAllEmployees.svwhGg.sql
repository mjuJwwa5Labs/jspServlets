CREATE PROCEDURE countAllEmployees()
  BEGIN
	select count(*) from employees;
END;

