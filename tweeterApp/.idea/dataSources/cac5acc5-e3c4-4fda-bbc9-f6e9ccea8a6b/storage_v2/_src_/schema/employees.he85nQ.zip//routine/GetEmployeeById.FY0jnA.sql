CREATE PROCEDURE GetEmployeeById(IN emp_no INT)
  BEGIN
	select * from employees e where e.emp_no = emp_no;
END;

