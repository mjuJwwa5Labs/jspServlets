CREATE PROCEDURE GetTotalSalaryByEmployeeIdByDates(IN  employee_id INT, IN start_date DATE, IN end_date DATE,
                                                   OUT message     VARCHAR(50), OUT totalSalary FLOAT)
  BEGIN
 -- procedura, która łączną sumę wynagrodzeń od-do,
 -- dla pracownika o podanym id, ale jeżeli nie znaleziono
 -- pracownik o podanym id, trzeba zwrócic 'no result found'
	DECLARE localMessage VARCHAR(20);
    DECLARE employeeCount int;
    
    select count(*) 
    into employeeCount 
    from salaries s 
    where s.emp_no;
    
    if (employeeCount > 0) then
        begin
			select sum(s.salary) 
			INTO totalSalary
			from salaries s
			where 
				STR_TO_DATE(s.from_date, '%Y-/%M-/%d') > DATE_FORMAT(start_date, '%Y-/%m-/%d')
				and STR_TO_DATE(s.end_date, '%Y-/%M-/%d') < DATE_FORMAT(end_date, '%Y-/%m-/%d')
				and s.emp_no = employee_id
			group by s.emp_no;
            select 'Employee found' into message;
		end;
	else 
		begin
			select 0 into totalSalary;
			-- select localMessage into message;
            select 'Employee not found' into message;
		end;
	END IF;
END;

