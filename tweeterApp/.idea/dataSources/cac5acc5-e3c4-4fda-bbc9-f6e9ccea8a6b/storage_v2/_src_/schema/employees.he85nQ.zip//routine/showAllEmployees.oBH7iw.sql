CREATE PROCEDURE showAllEmployees()
  BEGIN
	select * from employees;
END;

